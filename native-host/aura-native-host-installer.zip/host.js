#!/usr/bin/env node
import { GoogleGenerativeAI } from '@google/genai';
import { spawn } from 'child_process';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const config = JSON.parse(readFileSync(join(__dirname, 'config.json'), 'utf8'));
const genai = new GoogleGenerativeAI(config.geminiApiKey);

function readMessage() {
  return new Promise((resolve) => {
    const lengthBuffer = Buffer.alloc(4);
    process.stdin.read(4).copy(lengthBuffer);
    const length = lengthBuffer.readUInt32LE(0);
    const message = process.stdin.read(length).toString();
    resolve(JSON.parse(message));
  });
}

function sendMessage(msg) {
  const buffer = Buffer.from(JSON.stringify(msg));
  const header = Buffer.alloc(4);
  header.writeUInt32LE(buffer.length, 0);
  process.stdout.write(header);
  process.stdout.write(buffer);
}

async function speak(text) {
  return new Promise((resolve) => {
    const ps = spawn('powershell', ['-Command', `Add-Type -AssemblyName System.Speech; $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; $synth.Speak('${text.replace(/'/g, "''")}')`]);
    ps.on('close', resolve);
  });
}

async function handleMessage(msg) {
  try {
    if (msg.action === 'explain') {
      const model = genai.getGenerativeModel({ model: 'gemini-2.0-flash-exp' });
      const prompt = `${msg.question}\n\nContext:\n${msg.context}`;
      const result = await model.generateContent(prompt);
      const answer = result.response.text();
      
      await speak(answer);
      sendMessage({ success: true, answer, spoken: true });
    }
  } catch (error) {
    sendMessage({ success: false, error: error.message });
  }
}

(async () => {
  while (true) {
    const msg = await readMessage();
    await handleMessage(msg);
  }
})();
